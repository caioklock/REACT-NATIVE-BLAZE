import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    
    <View style={styles.container}>
    <img src="https://logodownload.org/wp-content/uploads/2022/08/blaze-logo.png" style={styles.blaze}></img>
      <Text style={styles.paragraph}>
     Faça seu login e comece a apostar e ganhar seu dinheiro
      </Text>
    <View style={styles.buttons}>
      <input type="search" placeholder="Se conecte com seu E-mail" style={styles.loginbar1}></input>
        <input type="search" placeholder="Insira sua senha" style={styles.loginbar2}></input>
    <button type="button" class="buttonTwo" style={styles.buttonTwo}>Clique aqui caso tenha esquecido a sua senha</button>
     <button type="button" class="buttonTwo" style={styles.buttonTwo}>Cadastre-se caso não tenha conta existente</button>
    </View>
    </View>
  );
}

const styles = StyleSheet.create({
 blaze: {
    marginTop: 150,
    padding: 30,
    paddingBottom: 0,
    justifyContent: 'center',
  },
  paragraph: {
    marginTop: -200,
    margin: 40,
    fontSize: 17,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'black',
    fontFamily: 'Times  ',
  },
  container: {
    flex: 1,
    justifyContent: 'space-between',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#FFFFF',
    padding: 10,
  },
  buttonTwo: {
    padding: 1,
    margin: 10,
    marginBottom: 10,
    color: 'black',
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'red'
  },


loginbar1: {
padding: 15,
marginBottom: 10,
 borderColor: 'red'
},
loginbar2: {
padding: 10,
 borderColor: 'red'
},




});